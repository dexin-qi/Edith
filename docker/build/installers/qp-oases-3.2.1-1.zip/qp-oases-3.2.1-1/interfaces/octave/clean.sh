rm *.*~
rm *.o
rm qpOASES qpOASES_sequence
